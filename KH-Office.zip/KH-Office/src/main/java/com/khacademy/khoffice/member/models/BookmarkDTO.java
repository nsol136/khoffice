package com.khacademy.khoffice.member.models;

public class BookmarkDTO {
	private int member_no;
	private int bmember_no;
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public int getBmember_no() {
		return bmember_no;
	}
	public void setBmember_no(int bmember_no) {
		this.bmember_no = bmember_no;
	}
	
}
