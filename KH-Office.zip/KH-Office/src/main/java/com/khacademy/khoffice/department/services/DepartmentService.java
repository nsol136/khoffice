package com.khacademy.khoffice.department.services;

import java.util.List;

import com.khacademy.khoffice.department.models.DepartmentDTO;

public interface DepartmentService {
	public List<DepartmentDTO> getDepartmentDTOList();
}
