package com.khacademy.khoffice.work_history.controllers;

import org.springframework.stereotype.Controller;

@Controller("WorkHistoryForm")
public class FormController {

}
