package com.khacademy.khoffice.department.models;

public class DepartmentDTO {
	private int department_no;
	private String name;
	
	public int getDepartment_no() {
		return department_no;
	}
	public void setDepartment_no(int department_no) {
		this.department_no = department_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
