package com.khacademy.khoffice.address.models;

public class BookmarkDTO {
	private int member_no;
	private int address_no;
	
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public int getAddress_no() {
		return address_no;
	}
	public void setAddress_no(int address_no) {
		this.address_no = address_no;
	}
	
}
