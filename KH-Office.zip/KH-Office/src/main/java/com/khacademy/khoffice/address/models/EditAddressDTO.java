package com.khacademy.khoffice.address.models;

public class EditAddressDTO {
	private int edit_address_no;
	private String edit_name;
	private String edit_company;
	private String edit_dept_position;
	private String edit_email;
	private String edit_phone;
	public int getEdit_address_no() {
		return edit_address_no;
	}
	public void setEdit_address_no(int edit_address_no) {
		this.edit_address_no = edit_address_no;
	}
	public String getEdit_name() {
		return edit_name;
	}
	public void setEdit_name(String edit_name) {
		this.edit_name = edit_name;
	}
	public String getEdit_company() {
		return edit_company;
	}
	public void setEdit_company(String edit_company) {
		this.edit_company = edit_company;
	}
	public String getEdit_dept_position() {
		return edit_dept_position;
	}
	public void setEdit_dept_position(String edit_dept_position) {
		this.edit_dept_position = edit_dept_position;
	}
	public String getEdit_email() {
		return edit_email;
	}
	public void setEdit_email(String edit_email) {
		this.edit_email = edit_email;
	}
	public String getEdit_phone() {
		return edit_phone;
	}
	public void setEdit_phone(String edit_phone) {
		this.edit_phone = edit_phone;
	}
	
	
}
