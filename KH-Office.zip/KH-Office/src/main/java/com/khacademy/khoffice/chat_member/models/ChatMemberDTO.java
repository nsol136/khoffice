package com.khacademy.khoffice.chat_member.models;

public class ChatMemberDTO {
	private int cwindowNo;
	private int memberNo;
	
	public int getCwindowNo() {
		return cwindowNo;
	}
	public void setCwindowNo(int cwindowNo) {
		this.cwindowNo = cwindowNo;
	}
	public int getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(int memberNo) {
		this.memberNo = memberNo;
	}
	
}
