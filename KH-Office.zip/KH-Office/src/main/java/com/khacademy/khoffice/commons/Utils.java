package com.khacademy.khoffice.commons;

public class Utils {
	// 유틸리티로 사용할 메서드 작성
	// 아래는 예시임
	public static String getCurrentDayTime() {
		String currTime = Long.toString(System.currentTimeMillis());
		return currTime ;
	}
}
